import { Injectable } from '@angular/core';
import {Product} from './product';
import {HttpClient} from '@angular/common/http'
@Injectable()
export class ProductService {
proArr:Product[]=[];
  constructor(private http:HttpClient) { }
  getProductDetails():any{
    return this.http.get('/assets/Product.json')
  }

  submit(pro:Product[])
  {
     this.proArr.map((x)=>{
       if(x.id ==pro.uid)
       {

       }
     })
    return pro;
  }
}
